import { TestBed } from '@angular/core/testing';

import { ImagesearchService } from './imagesearch.service';

describe('ImagesearchService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ImagesearchService = TestBed.get(ImagesearchService);
    expect(service).toBeTruthy();
  });
});
