import { Component } from '@angular/core';

import { ImagesearchService } from '../app/imagesearch.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  storedimages=[];
  title = 'MYsearchimages';
  searchkeyword="";
  searchimagebox=true;
  searchedImagesbox=false;
  responseList;
  toggletrue=false;

  constructor(private imageapiservice:ImagesearchService){

  }

 
  callservicemethod(){
  this.storedimages.push(this.searchkeyword);
  this.imageapiservice.getimagesajax(this.searchkeyword).subscribe(recent => {this.responseList = recent;
  console.log(this.responseList);
  this.searchimagebox=false;
   this.toggletrue=true;
  });
  
  console.log("service method called");

    }


callSearchImages(){
this.searchimagebox=true;
this.toggletrue=false;
this.searchedImagesbox=false;
    

}


callSearchedImages(){
 
  this.searchimagebox=false;
  this.toggletrue=false;
  this.searchedImagesbox=true;

}

  
}
