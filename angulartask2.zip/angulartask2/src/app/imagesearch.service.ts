import { Injectable } from '@angular/core';
import {HttpClient, HttpErrorResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ImagesearchService {

  constructor(private _http:HttpClient) { }

  getimagesajax(searchkeyword) {
    return this._http
      .get('https://pixabay.com/api/?key=16559472-13b7224bd5f364f9941f6b536&q='+searchkeyword+'&image_type=photo');
      
  }
  
}
